#!/usr/local/zend/bin/php
<?php
require(__DIR__ . '/vendor/autoload.php');

use Zend\Log;
use Zend\State;
use Zend\ZSWebApiClient;

if ($argc != 1) {
    die("Usage: {$argv[0]}\n");
}

$log = new Log('php://stdout');
$state = new State($log);
if (isset($state['WEB_API_KEY_NAME'], $state['WEB_API_KEY_HASH'], $state['NODE_ID'])) {
    $client = new ZSWebApiClient(null, null);
    $response = $client->tasksComplete([], [], true);
    while ($response['code'] < 500 && !$response['data']['tasksComplete']) {
        $log->log(Log::INFO, "Waiting for Zend Server to complete tasks");
        sleep(3);
        $response = $client->tasksComplete([], [], true);
    }

    $log->log(Log::INFO, "Zend server completed it's tasks");
}

exit(0);
